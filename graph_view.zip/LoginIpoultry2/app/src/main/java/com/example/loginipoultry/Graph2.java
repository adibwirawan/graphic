package com.example.loginipoultry;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.graphics.Color;
import android.os.Bundle;

import com.jjoe64.graphview.DefaultLabelFormatter;
import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.GridLabelRenderer;
import com.jjoe64.graphview.LegendRenderer;
import com.jjoe64.graphview.series.DataPoint;
import com.jjoe64.graphview.series.LineGraphSeries;

import java.text.SimpleDateFormat;
import java.util.Date;

public class Graph2 extends AppCompatActivity {

    LineGraphSeries<DataPoint> series;
    SimpleDateFormat sdf=new SimpleDateFormat("hh:mm:ss");

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_graph2);
        GraphView graph = (GraphView) findViewById(R.id.graphid);
        series = new LineGraphSeries<>(getDataPoint());
        graph.addSeries(series);

        graph.getGridLabelRenderer().setLabelFormatter(new DefaultLabelFormatter(){
            @Override
            public String formatLabel(double value, boolean isValueX) {
                if(isValueX){
                    return sdf.format(new Date((long) value));
                }else {
                    return super.formatLabel(value, isValueX);
                }
            }
        });

        //how many view needed in graph for date & time, turn this label on
        //graphView.getGridLabelRenderer().setNumHorizontalLabels(4);
    }

    private DataPoint[] getDataPoint(){
        DataPoint[] dp = new DataPoint[]{
                new DataPoint(new Date().getTime(),21),
                new DataPoint(new Date().getTime(),22),
                new DataPoint(new Date().getTime(),3),
                new DataPoint(new Date().getTime(),14),
                new DataPoint(new Date().getTime(),18),
                new DataPoint(new Date().getTime(),22),
                new DataPoint(new Date().getTime(),22),
                new DataPoint(new Date().getTime(),12)
        };
        return dp;
    }
}