package com.example.loginipoultry;

import android.graphics.Color;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import java.util.List;

import com.jjoe64.graphview.DefaultLabelFormatter;
import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.GridLabelRenderer;
import com.jjoe64.graphview.LegendRenderer;
import com.jjoe64.graphview.series.DataPoint;
import com.jjoe64.graphview.series.LineGraphSeries;

import java.text.SimpleDateFormat;
import java.util.Date;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;


public class Graph extends AppCompatActivity {

    ///////////////////////////////////////////////////////////////////////////// test
    public static class GraphData {
        public static List<Entry> getData() throws SQLException {
            Connection conn = DatabaseConnection.getConnection();
            String sql = "SELECT measurement, time FROM farm";
            PreparedStatement stmt = conn.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();

            List<Entry> entries = new ArrayList<>();
            while (rs.next()) {
                float x = rs.getFloat("measurement");
                float y = rs.getFloat("time");
                entries.add(new Entry(x, y));
            }
            conn.close();
            return entries;
        }
    }

    public static class DatabaseConnection {
        public static Connection getConnection() throws SQLException {
            String url = "jdbc:mysql://localhost/ipoultry";
            String username = "";
            String password = "";
            return DriverManager.getConnection(url, username, password);
        }
    }

    //////////////////////////////////////////////////////////////////////////// test

            @Override
            protected void onCreate(Bundle savedInstanceState) {
                super.onCreate(savedInstanceState);
                setContentView(R.layout.activity_graph);
                GraphView graph = (GraphView) findViewById(R.id.graph);
                GraphView graph_humidity = (GraphView) findViewById(R.id.graph_humidity);
                GraphView graph_ammonia = (GraphView) findViewById(R.id.graph_ammonia);

                ///////////////////////////// test
                LineChart chart = findViewById(R.id.chart);

                try {
                    List<Entry> data = GraphData.getData();
                    LineDataSet dataSet = new LineDataSet(data, "Data");
                    LineData lineData = new LineData(dataSet);
                    chart.setData(lineData);
                    chart.getXAxis().setPosition(XAxis.XAxisPosition.BOTTOM);
                    chart.invalidate();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
                ///////////////////////////////// test

                SimpleDateFormat sdf = new SimpleDateFormat("hh:mm:ss");

                //Data Input
                int[] Data_1= {
                        32,33,33,34,35,30,29,28,27,26,25,26,
                        27,28,29,30,30,31,32,33,34,36,34,28,
                        26,24,24,23,24,25,28,27,26,25,26,28,
                        34,33,33,34,35,30,29,28,27,26,25,26,
                        32,30,34,34,35,30,29,28,27,26,25,26,
                        34,33,33,34,35,30,29,28,27,26,25,26,
                        34,33,33,34,35,30,29,28,27,26,25,26,
                        34,33,33,34,35,30,29,28,27,26,25,26,};

                int[] Data_2= {
                        30,31,33,34,35,30,29,28,27,26,25,26,
                        26,24,24,23,24,25,28,27,26,25,26,27,
                        26,24,24,23,24,25,28,27,26,25,26,29,
                        26,24,24,23,24,25,28,27,26,25,28,30,
                        32,34,29,28,25,30,28,27,26,25,26,28,
                        26,24,24,23,24,25,28,27,26,25,26,28,
                        26,24,24,23,24,25,28,27,26,25,26,28,
                        26,24,24,23,24,25,28,27,26,25,26,28,};

                int[] Data_3= {
                        28,29,33,34,35,30,29,28,27,26,25,26,
                        24,23,22,32,33,34,30,31,32,31,39,38,
                        24,23,22,32,33,34,30,31,32,31,30,26,
                        34,33,33,34,35,30,29,28,27,26,25,26,
                        32,30,34,34,35,30,29,28,27,26,25,26,
                        24,23,22,32,33,34,30,31,32,31,30,26,
                        34,33,33,34,35,30,29,28,27,26,25,26,
                        24,23,22,32,33,34,30,31,32,31,30,26,};

                //For data 1 : coop 1 graph
                LineGraphSeries<DataPoint> series = new LineGraphSeries<DataPoint>();
                for (int i=0;i<95;i++) {
                    series.appendData(new DataPoint(new Date().getTime(),Data_1[i]),true,100);
                }

                //For data 2 : coop 2 graph
                LineGraphSeries<DataPoint> series2 = new LineGraphSeries<DataPoint>();
                for (int i=0;i<95;i++) {
                    series2.appendData(new DataPoint(new Date().getTime(),Data_2[i]),true,100);
                }

                //For data 3 : coop 3 graph
                LineGraphSeries<DataPoint> series3 = new LineGraphSeries<DataPoint>();
                for (int i=0;i<95;i++) {
                    series3.appendData(new DataPoint(new Date().getTime(),Data_3[i]),true,100);
                }

                //For data 3 : coop 3 graph
                series3.setColor(Color.rgb(0,100,0));
                series3.setTitle("Coop 3");
                series3.setDrawDataPoints(true);
                series3.setDataPointsRadius(10);// Dots points
                series3.setThickness(3);

                //For data 2 : coop 2 graph
                series2.setColor(Color.rgb(100,0,0));
                series2.setTitle("Coop 2");
                series2.setDrawDataPoints(true);
                series2.setDataPointsRadius(10);// Dots points
                series2.setThickness(3);

                //For data 1 : coop 1 graph
                series.setColor(Color.rgb(0,0,100));
                series.setTitle("Coop 1");
                series.setDrawDataPoints(true);
                series.setDataPointsRadius(10);// Dots points
                series.setThickness(3);

                graph.addSeries(series);//series data 1 : coop 1
                graph.addSeries(series2);//series data 2 : coop 2
                graph.addSeries(series3);//series data 3 : coop 3

                //

                graph.getLegendRenderer().setVisible(true);
                graph.getLegendRenderer().setAlign(LegendRenderer.LegendAlign.TOP);
                graph.getGridLabelRenderer().setLabelFormatter(new DefaultLabelFormatter(){
                    @Override
                    public String formatLabel(double value, boolean isValueX) {
                        if (isValueX) {
                            return sdf.format(new Date((long) value));
                        }else{
                        return super.formatLabel(value, isValueX);}
                    }
                });

                //
                GridLabelRenderer gridLabel = graph.getGridLabelRenderer();
                gridLabel.setHorizontalAxisTitle("Date & Time");
                gridLabel.setVerticalAxisTitle("Celcius (°C)");

                //give the x amount of value needed
                graph.getGridLabelRenderer().setNumHorizontalLabels(4);

                // activate horizontal zooming and scrolling
                graph.getViewport().setScalable(true);
                // activate horizontal scrolling
                graph.getViewport().setScrollable(true);
                // activate horizontal and vertical zooming and scrolling
                graph.getViewport().setScalableY(true);
                // activate vertical scrolling
                graph.getViewport().setScrollableY(true);

                // set manual X bounds
                //graph.getViewport().setXAxisBoundsManual(true);
                //graph.getViewport().setMinX(0);
                //graph.getViewport().setMaxX(100);

                // set manual Y bounds
                graph.getViewport().setYAxisBoundsManual(true);
                graph.getViewport().setMinY(20);
                graph.getViewport().setMaxY(40);


/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

                int[] Data_Hum_1= {
                        10,11,12,14,15,17,19,20,21,23,25,29,
                        31,33,35,36,35,32,32,33,34,36,34,28,
                        26,24,24,23,24,25,28,27,26,25,26,28,
                        34,36,38,40,35,30,29,28,27,26,25,26,
                        32,30,34,34,35,30,29,28,27,26,25,26,
                        34,33,33,34,35,30,29,28,27,26,25,26,
                        34,33,33,34,35,30,29,28,27,26,25,26,
                        34,33,33,34,35,30,29,28,27,26,25,26,};

                int[] Data_Hum_2= {
                        30,31,33,34,35,30,29,28,27,26,25,26,
                        26,24,24,23,24,25,28,27,26,25,26,27,
                        26,24,24,23,24,25,28,27,26,25,26,29,
                        26,24,24,23,24,25,28,27,26,25,28,30,
                        32,34,29,28,25,30,28,27,26,25,26,28,
                        26,24,24,23,24,25,28,27,26,25,26,28,
                        26,24,24,23,24,25,28,27,26,25,26,28,
                        26,24,24,23,24,25,28,27,26,25,26,28,};

                int[] Data_Hum_3= {
                        28,29,33,34,35,30,29,28,27,26,25,26,
                        24,23,22,32,33,34,30,31,32,31,39,38,
                        24,23,22,32,33,34,30,31,32,31,30,26,
                        34,33,33,34,35,30,29,28,27,26,25,26,
                        32,30,34,34,35,30,29,28,27,26,25,26,
                        24,23,22,32,33,34,30,31,32,31,30,26,
                        34,33,33,34,35,30,29,28,27,26,25,26,
                        24,23,22,32,33,34,30,31,32,31,30,26,};

                //For data 1 : coop 1 graph
                LineGraphSeries<DataPoint> series_hum = new LineGraphSeries<DataPoint>();
                for (int i=0;i<95;i++) {
                    series_hum.appendData(new DataPoint(new Date().getTime(),Data_Hum_1[i]),true,100);
                }

                //For data 2 : coop 2 graph
                LineGraphSeries<DataPoint> series_hum2 = new LineGraphSeries<DataPoint>();
                for (int i=0;i<95;i++) {
                    series_hum2.appendData(new DataPoint(new Date().getTime(),Data_Hum_2[i]),true,100);
                }

                //For data 3 : coop 3 graph
                LineGraphSeries<DataPoint> series_hum3 = new LineGraphSeries<DataPoint>();
                for (int i=0;i<95;i++) {
                    series_hum3.appendData(new DataPoint(new Date().getTime(),Data_Hum_3[i]),true,100);
                }

                series_hum3.setColor(Color.rgb(0,100,0));
                series_hum3.setTitle("Coop 3");
                series_hum3.setDrawDataPoints(true);
                series_hum3.setDataPointsRadius(10);// Dots points
                series_hum3.setThickness(3);

                series_hum2.setColor(Color.rgb(100,0,0));
                series_hum2.setTitle("Coop 2");
                series_hum2.setDrawDataPoints(true);
                series_hum2.setDataPointsRadius(10);// Dots points
                series_hum2.setThickness(3);

                //
                series_hum.setColor(Color.rgb(0,0,100));
                series_hum.setTitle("Coop 1");
                series_hum.setDrawDataPoints(true);
                series_hum.setDataPointsRadius(10);// Dots points
                series_hum.setThickness(3);

                graph_humidity.addSeries(series_hum);//series data 1 : coop 1
                graph_humidity.addSeries(series_hum2);//series data 2 : coop 2
                graph_humidity.addSeries(series_hum3);//series data 3 : coop 3

                //

                graph_humidity.getLegendRenderer().setVisible(true);
                graph_humidity.getLegendRenderer().setAlign(LegendRenderer.LegendAlign.TOP);
                graph_humidity.getGridLabelRenderer().setLabelFormatter(new DefaultLabelFormatter(){
                    @Override
                    public String formatLabel(double value, boolean isValueX) {
                        if (isValueX) {
                            return sdf.format(new Date((long) value));
                        }else{
                            return super.formatLabel(value, isValueX);}
                    }
                });

                //
                GridLabelRenderer gridLabel_hum = graph_humidity.getGridLabelRenderer();
                gridLabel_hum.setHorizontalAxisTitle("Date & Time");
                gridLabel_hum.setVerticalAxisTitle("Humidity (%)");

                //give the x amount of value needed
                graph_humidity.getGridLabelRenderer().setNumHorizontalLabels(4);

                // activate horizontal zooming and scrolling
                graph_humidity.getViewport().setScalable(true);
                // activate horizontal scrolling
                graph_humidity.getViewport().setScrollable(true);
                // activate horizontal and vertical zooming and scrolling
                graph_humidity.getViewport().setScalableY(true);
                // activate vertical scrolling
                graph_humidity.getViewport().setScrollableY(true);

                // set manual X bounds
                //graph.getViewport().setXAxisBoundsManual(true);
                //graph.getViewport().setMinX(0);
                //graph.getViewport().setMaxX(100);

                // set manual Y bounds
                graph_humidity.getViewport().setYAxisBoundsManual(true);
                graph_humidity.getViewport().setMinY(0);
                graph_humidity.getViewport().setMaxY(100);

///////////////////////////////////////////////////////////////////////////////////////////////////////

                int[] Data_Amm_1= {
                        10,11,12,14,15,17,19,20,21,23,25,29,
                        31,33,35,36,35,32,32,33,34,36,34,28,
                        26,24,24,23,24,25,28,27,26,25,26,28,
                        34,36,38,40,35,30,29,28,27,26,25,26,
                        32,30,34,34,35,30,29,28,27,26,25,26,
                        34,33,33,34,35,30,29,28,27,26,25,26,
                        34,33,33,34,35,30,29,28,27,26,25,26,
                        34,33,33,34,35,30,29,28,27,26,25,26,};

                int[] Dara_Amm_2= {
                        30,31,33,34,35,30,29,28,27,26,25,26,
                        26,24,24,23,24,25,28,27,26,25,26,27,
                        26,24,24,23,24,25,28,27,26,25,26,29,
                        26,24,24,23,24,25,28,27,26,25,28,30,
                        32,34,29,28,25,30,28,27,26,25,26,28,
                        26,24,24,23,24,25,28,27,26,25,26,28,
                        26,24,24,23,24,25,28,27,26,25,26,28,
                        26,24,24,23,24,25,28,27,26,25,26,28,};

                int[] Dara_Amm_3= {
                        28,29,33,34,35,30,29,28,27,26,25,26,
                        24,23,22,32,33,34,30,31,32,31,39,38,
                        24,23,22,32,33,34,30,31,32,31,30,26,
                        34,33,33,34,35,30,29,28,27,26,25,26,
                        32,30,34,34,35,30,29,28,27,26,25,26,
                        24,23,22,32,33,34,30,31,32,31,30,26,
                        34,33,33,34,35,30,29,28,27,26,25,26,
                        24,23,22,32,33,34,30,31,32,31,30,26,};

                //For data 1 : coop 1 graph
                LineGraphSeries<DataPoint> series_amm = new LineGraphSeries<DataPoint>();
                for (int i=0;i<95;i++) {
                    series_amm.appendData(new DataPoint(new Date().getTime(),Data_Amm_1[i]),true,100);
                }

                //For data 2 : coop 2 graph
                LineGraphSeries<DataPoint> series_amm2 = new LineGraphSeries<DataPoint>();
                for (int i=0;i<95;i++) {
                    series_amm2.appendData(new DataPoint(new Date().getTime(),Dara_Amm_2[i]),true,100);
                }

                //For data 3 : coop 3 graph
                LineGraphSeries<DataPoint> series_amm3 = new LineGraphSeries<DataPoint>();
                for (int i=0;i<95;i++) {
                    series_amm3.appendData(new DataPoint(new Date().getTime(),Dara_Amm_3[i]),true,100);
                }

                series_amm3.setColor(Color.rgb(0,100,0));
                series_amm3.setTitle("Coop 3");
                series_amm3.setDrawDataPoints(true);
                series_amm3.setDataPointsRadius(10);// Dots points
                series_amm3.setThickness(3);

                series_amm2.setColor(Color.rgb(100,0,0));
                series_amm2.setTitle("Coop 2");
                series_amm2.setDrawDataPoints(true);
                series_amm2.setDataPointsRadius(10);// Dots points
                series_amm2.setThickness(3);

                //
                series_amm.setColor(Color.rgb(0,0,100));
                series_amm.setTitle("Coop 1");
                series_amm.setDrawDataPoints(true);
                series_amm.setDataPointsRadius(10);// Dots points
                series_amm.setThickness(3);

                graph_ammonia.addSeries(series_amm);//series data 1 : coop 1
                graph_ammonia.addSeries(series_amm2);//series data 2 : coop 2
                graph_ammonia.addSeries(series_amm3);//series data 3 : coop 3

                //

                graph_ammonia.getLegendRenderer().setVisible(true);
                graph_ammonia.getLegendRenderer().setAlign(LegendRenderer.LegendAlign.TOP);
                graph_ammonia.getGridLabelRenderer().setLabelFormatter(new DefaultLabelFormatter(){
                    @Override
                    public String formatLabel(double value, boolean isValueX) {
                        if (isValueX) {
                            return sdf.format(new Date((long) value));
                        }else{
                            return super.formatLabel(value, isValueX);}
                    }
                });

                //
                GridLabelRenderer gridLabel_ammonia = graph_humidity.getGridLabelRenderer();
                gridLabel_ammonia.setHorizontalAxisTitle("Date & Time");
                gridLabel_ammonia.setVerticalAxisTitle("Ammonia (ppm)");

                //give the x amount of value needed
                graph_ammonia.getGridLabelRenderer().setNumHorizontalLabels(4);

                // activate horizontal zooming and scrolling
                graph_ammonia.getViewport().setScalable(true);
                // activate horizontal scrolling
                graph_ammonia.getViewport().setScrollable(true);
                // activate horizontal and vertical zooming and scrolling
                graph_ammonia.getViewport().setScalableY(true);
                // activate vertical scrolling
                graph_ammonia.getViewport().setScrollableY(true);

                // set manual X bounds
                //graph.getViewport().setXAxisBoundsManual(true);
                //graph.getViewport().setMinX(0);
                //graph.getViewport().setMaxX(100);

                // set manual Y bounds
                graph_ammonia.getViewport().setYAxisBoundsManual(true);
                graph_ammonia.getViewport().setMinY(0);
                graph_ammonia.getViewport().setMaxY(100);

            }


        }
